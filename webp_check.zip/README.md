# webp_check
used to check if images have a webp equivalent, and creates one
