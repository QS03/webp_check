CF_PURGE_CACHE = False
CF_ZONE_ID = ""
CF_API_TOKEN = ""

SITE_DOMAIN = "staging.ciffonedigital.com"
FLUSH_DATABASE = False
GIF_QUALITY = 40
